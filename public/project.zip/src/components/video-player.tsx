'use client';

import { useEffect, useRef } from 'react';
import { useVideoMute } from '@/context/video-mute-context';
import { cn } from '@/lib/utils';

export function VideoPlayer({ src, autoPlay = true, className }: { src: string, autoPlay?: boolean, className?: string }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const { isGloballyMuted, setActivePlayer } = useVideoMute();

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.muted = isGloballyMuted;
    }
  }, [isGloballyMuted]);

  useEffect(() => {
    if (!autoPlay) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        const video = videoRef.current;
        if (!video) return;

        if (entry.isIntersecting) {
          setActivePlayer(videoRef);
          video.play().catch((error) => {
            console.error("Autoplay blocked or interrupted:", error);
          });
        } else {
          video.pause();
        }
      },
      { threshold: 0.5 }
    );

    const currentVideoRef = videoRef.current;
    if (currentVideoRef) {
      observer.observe(currentVideoRef);
    }

    return () => {
      if (currentVideoRef) {
        observer.unobserve(currentVideoRef);
      }
    };
  }, [setActivePlayer, autoPlay]);

  return <video ref={videoRef} src={src} loop muted playsInline className={cn("w-full h-auto block object-cover", className)} />;
}
